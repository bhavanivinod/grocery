package com.htc.rest.DAO.Impl;

import java.util.List;

import com.htc.rest.pojo.Event;

public interface EventDAO {

	List<Event> getAllEvents();
	boolean persistEvent(Event event);
	Event getEventbyID(int id);
	boolean updateEvent(Event event);
	boolean deleteEvent(int id);
}
