package com.htc.rest.DAO.Impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.htc.rest.pojo.Event;

public class EventDAOImpl implements EventDAO {
	Map<Integer, Event> events = new HashMap<>();

	
	public EventDAOImpl() {
		Event event = new Event(101, "Mepz MArathon", new Date(), 100.00);

		Event event1 = new Event(103, "bud &blossoms painting", new Date(), 200.00);

		events.put(event.getEventID(), event);
		events.put(event.getEventID(), event);

	}

	@Override
	public boolean persistEvent(Event event) {
		boolean flag = false;
		events.put(event.getEventID(), event);
		return false;
	}

	@Override
	public List<Event> getAllEvents() {
		Collection<Event> output = events.values();
		return new ArrayList<>(output);
	}

}
