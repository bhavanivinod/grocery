package com.htc.rest.DAO.Impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.htc.rest.pojo.Event;

public class EventDAOImpl implements EventDAO {
	static Map<Integer, Event>  events = new HashMap<>();

	
	public EventDAOImpl() {
		Event event = new Event(101, "Mepz MArathon", new Date(), 100.00);

		Event event1 = new Event(103, "bud &blossoms painting", new Date(), 200.00);

		events.put(event.getEventID(), event);
		events.put(event1.getEventID(), event1);

	}
	
	

	@Override
	public boolean persistEvent(Event evt) {
		boolean flag = false;
		events.put(evt.getEventID(), evt);
	
		 flag=true;
		return flag;
	}

	@Override
	public List<Event> getAllEvents() {
		List<Event> output = new ArrayList<>( events.values());
		System.out.println(output);
		return output;
	}



	@Override
	public Event getEventbyID(int id) {
		// TODO Auto-generated method stub
		return events.get(id);
	}



	@Override
	public boolean updateEvent(Event event) {
		boolean flag = false;
		
		events.put(event.getEventID(), event);
	
		 flag=true;
		return flag;
		
	}



	@Override
	public boolean deleteEvent(int id) {
		boolean flag = false;
	    events.remove(new Integer(id));
		 flag=true;
		return flag;
	}

}
