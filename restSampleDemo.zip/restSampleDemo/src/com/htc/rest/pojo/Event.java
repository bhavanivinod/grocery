package com.htc.rest.pojo;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
@XmlAccessorType(XmlAccessType.NONE)
public class Event implements Serializable{
	@XmlElement
 private int eventID;
	@XmlElement
 private String eventDesc;
	@XmlElement
 private Date eventDate;
	@XmlElement
 private double regFees;
 
 public Event() {
	// TODO Auto-generated constructor stub
}

public Event(int eventID, String eventDesc, Date eventDate, double regFees) {
	super();
	this.eventID = eventID;
	this.eventDesc = eventDesc;
	this.eventDate = eventDate;
	this.regFees = regFees;
}

public int getEventID() {
	return eventID;
}

public void setEventID(int eventID) {
	this.eventID = eventID;
}

public String getEventDesc() {
	return eventDesc;
}

public void setEventDesc(String eventDesc) {
	this.eventDesc = eventDesc;
}

public Date getEventDate() {
	return eventDate;
}

public void setEventDate(Date eventDate) {
	this.eventDate = eventDate;
}

public double getRegFees() {
	return regFees;
}

public void setRegFees(double regFees) {
	this.regFees = regFees;
}

@Override
public String toString() {
	return "Event [eventID=" + eventID + ", eventDesc=" + eventDesc + ", eventDate=" + eventDate + ", regFees="
			+ regFees + "]";
}
 
 
 
  
}
