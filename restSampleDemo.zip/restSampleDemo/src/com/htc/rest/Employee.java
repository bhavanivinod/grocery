package com.htc.rest;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.htc.rest.pojo.Event;
import com.htc.rest.service.Impl.EventService;
import com.htc.rest.service.Impl.EventServiceImpl;

@Path("/employee")
public class Employee {
	
	EventService service= new EventServiceImpl();

	/*//@Path("/plainmsg")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String sayHello()
	{
		 return "Hi hello";
	}
	
	//@Path("/htmlmsg")
	@GET
	@Produces(MediaType.TEXT_HTML )
	public String sayHelloHTML()
	{
		 return "<html>"+"<body><h1>"+"Hi hello"+"</h1></body>"+"</html>";
	}
	*/
	
	
	@Path("/xmlmsg")
	@GET
	@Produces(MediaType.APPLICATION_XML )
	public String sayHelloXML()
	{
		 return "<user>\r\n" + 
		 		"<name>bhavani</name>\r\n" + 
		 		"</user>" ;
}
	
	
	
	
	
	@Path("/getAll")
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Event> getEvents() {
		// TODO Auto-generated method stub
		return service.getEvents();
	}
	
	
	
}
