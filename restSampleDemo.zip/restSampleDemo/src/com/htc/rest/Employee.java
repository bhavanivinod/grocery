package com.htc.rest;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.htc.rest.pojo.Event;
import com.htc.rest.service.Impl.EventService;
import com.htc.rest.service.Impl.EventServiceImpl;

@Path("/employee")
public class Employee {

	EventService service=new EventServiceImpl();
	//@Path("/plainmsg")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String sayHello()
	{
		 return "Hi hello";
	}
	
	//@Path("/htmlmsg")
	@GET
	@Produces(MediaType.TEXT_HTML )
	public String sayHelloHTML()
	{
		 return "<html>"+"<body><h1>"+"Hi hello"+"</h1></body>"+"</html>";
	}
	
	//@Path("/xmlmsg")
	@GET
	@Produces(MediaType.APPLICATION_XML )
	public String sayHelloXML()
	{
		 return "<user>\r\n" + 
		 		"<name>bhavani</name>\r\n" + 
		 		"</user>" ;
}
	
	
	@Path("/getAll")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Event> getEvents() {
		// TODO Auto-generated method stub
		return service.getEvents();
	}
	
	
	@Path("/storedata")
	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.APPLICATION_JSON)
	public String StoreEvents(Event event) {
		// TODO Auto-generated method stub
		return service.addEvent(event);
	}
	
	
	@Path("/get/{id}")
	@GET
	@Produces(MediaType.APPLICATION_XML)
	
	public Event getEvent(@PathParam("id") int id) {
		// TODO Auto-generated method stub
		Event evt= service.getEventById(id);
		return evt;
	}
	
	@Path("/updatedata")
	@PUT
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateEvent(Event event) {
		// TODO Auto-generated method stub
		return service.updateEvent(event);
	}
	
	@Path("/deletedata/{id}")
	@DELETE
	@Produces(MediaType.TEXT_PLAIN)
	
	public String deleteEvent(@PathParam("id") int id) {
		// TODO Auto-generated method stub
		return service.deleteEvent(id);
	}
}
