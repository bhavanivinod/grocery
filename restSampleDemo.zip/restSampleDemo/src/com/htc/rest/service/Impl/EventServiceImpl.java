package com.htc.rest.service.Impl;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.htc.rest.DAO.Impl.EventDAO;
import com.htc.rest.DAO.Impl.EventDAOImpl;
import com.htc.rest.pojo.Event;

//@Path ("/eventService")
public class EventServiceImpl implements EventService {

	EventDAO dao=new EventDAOImpl();
	@Override
	
	/*@Path("/store")
	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.APPLICATION_JSON)*/
	public String addEvent(Event event) {
		// TODO Auto-generated method stub
		String data;
		if(dao.persistEvent(event))
	data= "Data added successfully" ;
		else
			data= "There may be an error " ;
		return null;
	}

	@Override
	/*@Path("/getAll")
	@GET
	@Produces(MediaType.APPLICATION_XML)*/
	public List<Event> getEvents() {
		// TODO Auto-generated method stub
		return dao.getAllEvents();
	}

}
