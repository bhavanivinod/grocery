package com.htc.rest.service.Impl;


import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.htc.rest.pojo.Event;

//@Path ("/eventService")
public interface EventService {
	/*@Path("/store")
	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.APPLICATION_JSON)*/
	String addEvent(Event event);
	
	/*@Path("/getAll")
	@GET
	@Produces(MediaType.APPLICATION_XML)*/
		List<Event> getEvents();
	
	
	

}
