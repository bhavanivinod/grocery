package lk.codelabs.rentcloud.rentprocesstask.service;

/**
 * @author Krishantha Dinesh
 * krishantha@krishantha.com
 * www.krishantha.com
 * twitter @krishantha
 * on 17-October-2019 01:24
 * @Project rent-process-task
 */
public interface RentProcessService {
    boolean validateDL(String dlNumber);
}
