Youtube: https://www.youtube.com/krish
LinkedIn: https://www.linkedin.com/in/krish-din/
Instagram: https://www.instagram.com/krish.din/
facebook: https://www.facebook.com/krish.page
facebook: https://www.facebook.com/capturedDreams
twitter: https://twitter.com/krishantha (@Krishantha)
