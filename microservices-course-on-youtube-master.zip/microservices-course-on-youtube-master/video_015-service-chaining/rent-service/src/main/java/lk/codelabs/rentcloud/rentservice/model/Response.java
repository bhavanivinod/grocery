package lk.codelabs.rentcloud.rentservice.model;

/**
 * @author Krishantha Dinesh
 * krishantha@krishantha.com
 * www.krishantha.com
 * twitter @krishantha
 * on 22-October-2019 23:24
 * @Project rent-service
 */
public interface Response {
}
