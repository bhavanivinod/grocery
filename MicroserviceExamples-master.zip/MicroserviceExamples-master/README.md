# MicroserviceExamples

Please contact me for Spring boot with Microsesrvices realtime online training.

email : kvsravindrareddy@gmail.com
info@trendingtechnologies.in

We provide class room, online and corporate training



Oauth2 and JWT with Database example and API gateway integration

Please download the examples to integrate with Zuul API gateway and Oauth2 and JWT with Database example
