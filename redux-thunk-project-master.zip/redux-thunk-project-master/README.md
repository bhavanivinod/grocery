##Steps of running this project

from the command prompt clone the project

* $git clone https://github.com/techsithgit/react-thunk-project.git
* $cd react-thunk-project
* $npm install
* $npm start

[Watch the Tutorial](https://youtu.be/Sqkm39rqmEg).
