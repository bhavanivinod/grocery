package com.htc.rest.client;

import javax.ws.rs.core.MediaType;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class TestClient {

	public static void main(String[] args) {
		Client client=Client.create();
		WebResource resource=client.resource("http://localhost:8081/restSampleDemo/rest/employee");
		ClientResponse response=resource.accept(MediaType.APPLICATION_XML).get(ClientResponse.class);
		String output;
		if(response.getStatus()==200)
		{
			output=response.getEntity(String.class);
		}
		else
		{
			throw new RuntimeException("Failed : HTTP error code : "
                    + response.getStatus());
		}
		
		System.out.println(output);
	}

}
