package com.htc.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/employee")
public class Employee {

	//@Path("/plainmsg")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String sayHello()
	{
		 return "Hi hello";
	}
	
	//@Path("/htmlmsg")
	@GET
	@Produces(MediaType.TEXT_HTML )
	public String sayHelloHTML()
	{
		 return "<html>"+"<body><h1>"+"Hi hello"+"</h1></body>"+"</html>";
	}
	
	//@Path("/xmlmsg")
	@GET
	@Produces(MediaType.APPLICATION_XML )
	public String sayHelloXML()
	{
		 return "<user>\r\n" + 
		 		"<name>bhavani</name>\r\n" + 
		 		"</user>" ;
}
}
