package com.htc.service;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/employee")
public class MyjerseyPage {
	
	@GET	
	@Produces(MediaType.TEXT_HTML)
	public String greeting()
	{
		return "Good morning";
	}

}
